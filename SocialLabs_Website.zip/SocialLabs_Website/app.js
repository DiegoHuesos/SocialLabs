//npm install --save express body-parser express-handlebars nodemailer

const express = require('express');
const bodyParser  = require('body-parser');
const exphbs = require('express-handlebars');
const path = require('path')
const nodemailer = require('nodemailer');

const app = express();

//View engine setup
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');

//Static Folder
app.use('', express.static(path.join(__dirname, 'public')));

//Body Parser Middleware
app.use(bodyParser.urlencoded({ extended: false}));
app.use(bodyParser.json());

app.get('/', (req, res)=> {
    res.render('index', {layout: false});
});
app.get('/home', (req, res)=> {
    res.render('index', {layout: false});
});
app.get('/index', (req, res)=> {
    res.render('index.html', {layout: false});
});
app.get('/index.html', (req, res)=> {
    res.render('index', {layout: false});
});
app.get('/about', (req, res)=> {
    res.render('about', {layout: false});
});
app.get('/about.html', (req, res)=> {
    res.render('about', {layout: false});
});
app.get('/ad-hoc', (req, res)=> {
    res.render('ad-hoc', {layout: false});
});
app.get('/ad-hoc.html', (req, res)=> {
    res.render('ad-hoc', {layout: false});
});
app.get('/certificacion', (req, res)=> {
    res.render('certificacion', {layout: false});
});
app.get('/certificacion.html', (req, res)=> {
    res.render('certificacion', {layout: false});
});
app.get('/clientes', (req, res)=> {
    res.render('clientes', {layout: false});
});
app.get('/clientes.html', (req, res)=> {
    res.render('clientes', {layout: false});
});
app.get('/contacto', (req, res)=> {
    res.render('contacto', {layout: false});
});
app.get('/contacto.html', (req, res)=> {
    res.render('contacto', {layout: false});
});

app.get('/english/home-en.html', (req, res)=> {
    res.render('english/home-en', {layout: false});
});
app.get('/english/contact-en.html', (req, res)=> {
    res.render('english/contact-en', {layout: false});
});
app.get('/english/cliente-en.html', (req, res)=> {
    res.render('english/cliente-en', {layout: false});
});
app.get('/english/certificacion-en.html', (req, res)=> {
    res.render('english/certificacion-en', {layout: false});
});
app.get('/english/ad-hoc-en.html', (req, res)=> {
    res.render('english/ad-hoc-en', {layout: false});
});
app.get('/english/about-en.html', (req, res)=> {
    res.render('english/about-en', {layout: false});
});

app.post('/send', (req, res)=> {
    const output = `
        <p> You have a contact request </p>
        <h3> Contact Details </h3>
        <ul>
            <li>Nombre: ${req.body.name} </li>
            <li>Apellido: ${req.body.apellido} </li>
            <li>Company: ${req.body.compania} </li>
            <li>Email: ${req.body.email} </li>
            <li>Teléfono: ${req.body.telefono} </li>
            <li>Sector: ${req.body.sector} </li>
            <li>Puesto: ${req.body.puesto} </li>
            <li>Tipo de consulta: ${req.body.tipo_consulta} </li>
        </ul>
        <h3> Message</h3>
        <p> ${req.body.mensaje} </p>
    `;

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
    //host: 'mail.YOURDOMAIN.com',
    //port: 587,
    service: 'gmail',
    secure: false, // true for 465, false for other ports
    auth: {
        user: 'sociallabs.test123@gmail.com', // generated ethereal user
        pass: 'SocialLabs123'  // generated ethereal password
    },
    tls:{
      rejectUnauthorized:false
    }
  });

  // setup email data with unicode symbols
  let mailOptions = {
      from: '"SocialLabs Web App" <sociallabs.test123@gmail.com>', // sender address
      to: 'sociallabs.test123@gmail.com, edgar.vicente@sociallabs.biz',  // list of receivers
      subject: 'Website SocialLabs Lead Contact', // Subject line
      text: 'Hello, SocialLabs!', // plain text body
      html: output // html body
  };

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
          return console.log(error);
      }
      console.log('Message sent: %s', info.messageId);   
      console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));

      res.render('index', {layout: false});
  });
});

var port = process.env.PORT || 1337;

app.listen(port, ()=> console.log('Server started'));